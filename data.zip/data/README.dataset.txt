# bigspoon_detection > 2024-04-28 5:42pm
https://universe.roboflow.com/seines-workspace/bigspoon_detection

Provided by a Roboflow user
License: CC BY 4.0

